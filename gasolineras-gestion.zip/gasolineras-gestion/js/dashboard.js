/* ==========================================================
   dashboard.js — Pinta el Dashboard con datos de Api.getDashboard()
   Se vuelve a ejecutar cada vez que cambia la estación elegida.
   ========================================================== */
"use strict";

(async function () {
  if (!Auth.requireSession()) return;
  await Shell.render("dashboard");

  const $ = (id) => document.getElementById(id);
  const PALETTE = ["#1f5f6b", "#d19a2a", "#6b7f8c", "#a5483b", "#8aa79a", "#b9c2c8"];
  const charts = {};

  // Estilo base de Chart.js
  Chart.defaults.font.family = '"IBM Plex Sans", system-ui, sans-serif';
  Chart.defaults.color = "#66757f";
  Chart.defaults.borderColor = "#e8ecee";

  /* Crea (o recrea) un gráfico */
  function draw(key, canvasId, config) {
    if (charts[key]) charts[key].destroy();
    charts[key] = new Chart($(canvasId), config);
  }

  const moneyTick = (v) => "S/ " + Fmt.number(v);
  const noLegend = { legend: { display: false } };

  /* ---------- Bloques de la pantalla ---------- */
  function renderKpis(k) {
    const now = new Date();
    $("kVentasDia").textContent = Fmt.money(k.ventasDia);
    $("kVentasMes").textContent = Fmt.money(k.ventasMes);
    $("kGastos").textContent = Fmt.money(k.gastosMes);
    $("kUtilidad").textContent = Fmt.money(k.utilidad);
    $("kDiaNote").textContent = now.toLocaleDateString(CONFIG.locale, { day: "numeric", month: "long" });
    $("kMesNote").textContent = now.toLocaleDateString(CONFIG.locale, { month: "long", year: "numeric" });
  }

  function renderCharts(d) {
    draw("ventas", "chVentas", {
      type: "line",
      data: {
        labels: d.ventasPorDia.labels,
        datasets: [{
          label: "Ventas", data: d.ventasPorDia.values,
          borderColor: PALETTE[0], backgroundColor: "rgba(31,95,107,.10)",
          fill: true, tension: 0.3, pointRadius: 3, pointBackgroundColor: PALETTE[0],
        }],
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { ...noLegend, tooltip: { callbacks: { label: (c) => Fmt.money(c.parsed.y) } } },
        scales: { y: { beginAtZero: true, ticks: { callback: moneyTick } }, x: { grid: { display: false } } },
      },
    });

    $("distTitle").textContent = d.distribucion.title;
    draw("dist", "chDist", {
      type: "doughnut",
      data: { labels: d.distribucion.labels, datasets: [{ data: d.distribucion.values, backgroundColor: PALETTE, borderWidth: 2, borderColor: "#fff" }] },
      options: {
        responsive: true, maintainAspectRatio: false, cutout: "62%",
        plugins: { legend: { position: "bottom", labels: { boxWidth: 10, boxHeight: 10 } }, tooltip: { callbacks: { label: (c) => ` ${c.label}: ${Fmt.money(c.parsed)}` } } },
      },
    });

    draw("fuel", "chFuel", {
      type: "bar",
      data: { labels: d.combustible.labels, datasets: [{ label: "Litros", data: d.combustible.values, backgroundColor: PALETTE, borderRadius: 3, maxBarThickness: 56 }] },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { ...noLegend, tooltip: { callbacks: { label: (c) => ` ${Fmt.number(c.parsed.y)} L` } } },
        scales: { y: { beginAtZero: true, ticks: { callback: (v) => Fmt.number(v) } }, x: { grid: { display: false } } },
      },
    });
  }

  /* Tanques: la marca vertical indica el stock mínimo */
  function renderTanks(list) {
    $("tanks").innerHTML = list.map((t) => {
      const pct = t.capacity ? Math.min(100, (t.stock / t.capacity) * 100) : 0;
      const minPct = t.capacity ? (t.min / t.capacity) * 100 : 0;
      const state = t.stock <= t.min ? "danger" : t.stock <= t.min * 1.25 ? "warn" : "";
      return `<div class="tank">
        <div class="tank-top"><span class="fw-medium">${esc(t.fuel)}</span>
          <span class="lts num">${Fmt.number(t.stock)} / ${Fmt.number(t.capacity)} L</span></div>
        <div class="tank-bar" role="img" aria-label="${esc(t.fuel)} al ${Math.round(pct)}%">
          <div class="tank-fill ${state}" style="width:${pct}%"></div>
          <span class="tank-min" style="left:${minPct}%" title="Stock mínimo"></span>
        </div></div>`;
    }).join("") + `<div class="tank-legend">La marca oscura indica el stock mínimo.</div>`;
  }

  function renderOps(list) {
    const cls = { Venta: "venta", Compra: "compra", Gasto: "gasto" };
    $("opsBody").innerHTML = list.length ? list.map((o) => `
      <tr>
        <td class="num">${esc(o.h)}</td>
        <td>${esc(o.estacion)}</td>
        <td><span class="tag ${cls[o.t] || ""}">${esc(o.t)}</span></td>
        <td>${esc(o.d)}</td>
        <td class="text-end num ${o.t === "Venta" ? "amt-in" : "amt-out"}">${o.t === "Venta" ? "+" : "−"} ${Fmt.money(o.m)}</td>
      </tr>`).join("")
      : `<tr><td colspan="5" class="empty">Aún no hay operaciones registradas hoy.</td></tr>`;
  }

  function renderAlerts(list) {
    const icon = { danger: "fa-circle-exclamation", warning: "fa-triangle-exclamation", info: "fa-circle-info" };
    $("alerts").innerHTML = list.length ? list.map((a) => `
      <div class="alert-x ${esc(a.level)}">
        <i class="fa-solid ${icon[a.level] || icon.info}"></i>
        <div><div>${esc(a.text)}</div><div class="meta">${esc(a.meta || "")}</div></div>
      </div>`).join("")
      : `<div class="empty">Sin alertas por ahora.</div>`;
  }

  /* ---------- Carga de datos ---------- */
  async function load() {
    const content = $("content");
    content.classList.add("is-loading");
    try {
      const stationId = App.getStation();
      const d = await Api.getDashboard(stationId);
      const name = stationId === "all" ? "todas las estaciones" : $("stationSelect").selectedOptions[0]?.textContent || stationId;
      $("scopeText").textContent = `Resumen de ${name}`;
      renderKpis(d.kpis);
      renderCharts(d);
      renderTanks(d.inventario);
      renderOps(d.operaciones);
      renderAlerts(d.alertas);
    } catch (err) {
      console.error(err);
      $("scopeText").textContent = "No se pudo cargar la información. Recarga la página.";
    } finally {
      content.classList.remove("is-loading");
    }
  }

  document.addEventListener("station:change", load);
  load();
})();
