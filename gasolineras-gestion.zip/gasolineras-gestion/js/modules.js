/* ==========================================================
   modules.js — Configuración de cada módulo (estaciones, ventas,
   inventario, personal, gastos). Para agregar un campo nuevo o
   una columna, solo se añade una línea en "fields".
   ========================================================== */
"use strict";

const stationOpts = () => Store.all("estaciones").map((s) => ({ value: s.id, label: s.nombre }));
const activeStationOpts = () => Store.all("estaciones").filter((s) => s.estado === "Activa").map((s) => ({ value: s.id, label: s.nombre }));
const workerOpts = () => Store.all("personal").filter((p) => ["Despachador", "Encargado"].includes(p.cargo)).map((p) => ({ value: p.id, label: p.nombre }));
const allWorkerOpts = () => Store.all("personal").map((p) => ({ value: p.id, label: p.nombre }));
const tag = (text, cls) => `<span class="tag ${cls}">${esc(text)}</span>`;
const nowHHMM = () => new Date().toTimeString().slice(0, 5);
const dupError = (rows, row, test, msg) => { if (rows.some((r) => (!row || r.id !== row.id) && test(r))) throw new Error(msg); };

const Modules = {
  /* ---------------- ESTACIONES ---------------- */
  estaciones: {
    key: "estaciones", collection: "estaciones", title: "Estaciones", subtitle: "Administra tus estaciones de servicio.",
    newLabel: "Nueva estación", itemLabel: (r) => `${r.codigo} · ${r.nombre}`, sort: { key: "codigo", dir: "asc" },
    canDelete: false,   // las estaciones se desactivan, no se borran (protege el historial)
    filters: [{ key: "estado", label: "Estado" }],
    fields: [
      { key: "codigo", label: "Código", required: true, placeholder: "EST-005" },
      { key: "nombre", label: "Nombre", required: true },
      { key: "direccion", label: "Dirección", table: false },
      { key: "ciudad", label: "Ciudad" },
      { key: "estado", label: "Estado", options: ["Activa", "Inactiva", "Planificada"], required: true,
        render: (r) => tag(r.estado, r.estado === "Activa" ? "venta" : r.estado === "Inactiva" ? "gasto" : "compra") },
      { key: "surtidores", label: "N.º de surtidores", type: "number", required: true },
      { key: "combustibles", label: "Tipos de combustible", hint: "Separados por coma", table: false },
      { key: "responsable", label: "Responsable" },
      { key: "horario", label: "Horario", placeholder: "24 horas" },
      { key: "info", label: "Información adicional", type: "textarea", table: false },
    ],
    beforeSave: (v, row, rows) => dupError(rows, row, (r) => r.codigo.toLowerCase() === v.codigo.toLowerCase(), "Ya existe una estación con ese código."),
    actions: [{
      icon: "fa-power-off", title: "Activar / desactivar",
      handler: async (r) => {
        const estado = r.estado === "Activa" ? "Inactiva" : "Activa";
        if (estado === "Inactiva" && !confirm(`¿Desactivar ${r.nombre}? Dejará de aparecer para nuevas ventas.`)) return;
        await Api.update("estaciones", r.id, { estado });
        Toast.show(`${r.nombre}: ${estado.toLowerCase()}.`);
      },
    }],
  },

  /* ---------------- VENTAS ---------------- */
  ventas: {
    key: "ventas", collection: "ventas", title: "Ventas", subtitle: "Registro de despachos por estación, surtidor y trabajador.",
    newLabel: "Registrar venta", itemLabel: (r) => `Venta ${r.id} · ${Fmt.date(r.fecha)} ${r.hora}`,
    sort: { key: "fecha", dir: "desc" }, tieBreak: (a, b) => a.hora.localeCompare(b.hora),
    defaults: () => ({ fecha: Store.iso(), hora: nowHHMM(), metodo: "Efectivo" }),
    filters: [
      { key: "fecha", label: "Fecha", type: "daterange" }, { key: "estacion", label: "Estación" },
      { key: "trabajador", label: "Trabajador" }, { key: "combustible", label: "Combustible" }, { key: "metodo", label: "Pago" },
    ],
    fields: [
      { key: "fecha", label: "Fecha", type: "date", required: true },
      { key: "hora", label: "Hora", type: "time", required: true },
      { key: "estacion", label: "Estación", options: activeStationOpts, required: true },
      { key: "surtidor", label: "Surtidor", type: "number", min: 1, required: true },
      { key: "trabajador", label: "Trabajador", options: workerOpts, required: true },
      { key: "combustible", label: "Combustible", options: FUELS, required: true },
      { key: "litros", label: "Litros", type: "number", step: "0.01", required: true, validate: (v) => (v <= 0 ? "Debe ser mayor a 0." : "") },
      { key: "precio", label: "Precio por litro (S/)", type: "money", required: true, hint: "Se completa solo según el inventario; puedes cambiarlo." },
      { key: "total", label: "Total (S/)", type: "money", computed: (v) => Math.round((v.litros || 0) * (v.precio || 0) * 100) / 100, hint: "Litros × precio, automático." },
      { key: "metodo", label: "Método de pago", options: PAY_METHODS, required: true },
    ],
    // Al elegir estación + combustible, trae el precio de venta del inventario
    onChange: (v, set, changed) => {
      if (changed !== "estacion" && changed !== "combustible") return;
      const inv = Store.all("inventario").find((i) => i.estacion === v.estacion && i.combustible === v.combustible);
      if (inv) set("precio", inv.precioVenta);
    },
    summary: (rows) => `<span><b>${rows.length}</b> ventas</span><span><b>${Fmt.number(rows.reduce((a, r) => a + r.litros, 0))}</b> litros</span><span><b>${Fmt.money(rows.reduce((a, r) => a + r.total, 0))}</b> total</span>`,
  },

  /* ---------------- INVENTARIO ---------------- */
  inventario: {
    key: "inventario", collection: "inventario", title: "Inventario", subtitle: "Stock de combustible por estación. El stock se descuenta solo con cada venta.",
    newLabel: "Nuevo tanque", itemLabel: (r) => `${Store.stationName(r.estacion)} · ${r.combustible}`, sort: { key: "estacion", dir: "asc" },
    filters: [{ key: "estacion", label: "Estación" }, { key: "combustible", label: "Combustible" }],
    rowClass: (r) => (Store.stock(r).actual <= r.minimo ? "row-low" : ""),
    fields: [
      { key: "estacion", label: "Estación", options: stationOpts, required: true },
      { key: "combustible", label: "Combustible", options: FUELS, required: true },
      { key: "stockInicial", label: "Stock inicial (L)", type: "number", step: "0.01", required: true },
      { key: "compras", label: "Compras acumuladas (L)", type: "number", step: "0.01", required: true },
      { key: "vendido", label: "Ventas (L)", type: "number", virtual: (r) => Store.stock(r).vendido },
      { key: "stockActual", label: "Stock actual (L)", type: "number", virtual: (r) => Store.stock(r).actual },
      { key: "precioCompra", label: "Precio compra", type: "money", required: true },
      { key: "precioVenta", label: "Precio venta", type: "money", required: true },
      { key: "margen", label: "Margen / L", type: "money", virtual: (r) => Math.round((r.precioVenta - r.precioCompra) * 100) / 100 },
      { key: "minimo", label: "Stock mínimo (L)", type: "number", required: true, table: false },
      { key: "capacidad", label: "Capacidad del tanque (L)", type: "number", required: true, table: false },
      { key: "estadoStock", label: "Estado", virtual: (r) => { const s = Store.stock(r).actual; return s <= r.minimo ? "Stock bajo" : s <= r.minimo * 1.25 ? "Por agotarse" : "Normal"; },
        render: (r) => { const s = Store.stock(r).actual; return s <= r.minimo ? tag("Stock bajo", "gasto") : s <= r.minimo * 1.25 ? tag("Por agotarse", "warn") : tag("Normal", "venta"); } },
    ],
    beforeSave: (v, row, rows) => dupError(rows, row, (r) => r.estacion === v.estacion && r.combustible === v.combustible, "Ese combustible ya existe en esa estación. Edita el registro existente."),
    actions: [{
      icon: "fa-truck-ramp-box", title: "Registrar compra de combustible",
      handler: async (r) => {
        const l = parseFloat((prompt(`Litros comprados de ${r.combustible} (${Store.stationName(r.estacion)}):`) || "").replace(",", "."));
        if (!(l > 0)) return;
        await Api.update("inventario", r.id, { compras: Math.round((r.compras + l) * 100) / 100 });
        Toast.show(`Compra registrada: +${Fmt.number(l)} L.`);
      },
    }],
  },

  /* ---------------- PERSONAL ---------------- */
  personal: {
    key: "personal", collection: "personal", title: "Personal", subtitle: "Trabajadores por estación, cargo y turno.",
    newLabel: "Nuevo trabajador", itemLabel: (r) => r.nombre, sort: { key: "nombre", dir: "asc" },
    filters: [{ key: "estacion", label: "Estación" }, { key: "cargo", label: "Cargo" }, { key: "estado", label: "Estado" }],
    defaults: () => ({ estado: "Activo", ingreso: Store.iso() }),
    fields: [
      { key: "nombre", label: "Nombre completo", required: true },
      { key: "dni", label: "DNI", required: true, maxlength: 8, pattern: /^\d{8}$/, patternMsg: "El DNI tiene 8 números." },
      { key: "cargo", label: "Cargo", options: CARGOS, required: true },
      { key: "estacion", label: "Estación", options: stationOpts, required: true },
      { key: "telefono", label: "Teléfono", maxlength: 9, pattern: /^9\d{8}$/, patternMsg: "Celular de 9 dígitos que empiece con 9." },
      { key: "ingreso", label: "Fecha de ingreso", type: "date", required: true },
      { key: "estado", label: "Estado", options: ["Activo", "Inactivo"], required: true,
        render: (r) => tag(r.estado, r.estado === "Activo" ? "venta" : "gasto") },
      { key: "turno", label: "Turno", options: ["Mañana", "Tarde", "Noche", "Rotativo"], required: true },
    ],
    beforeSave: (v, row, rows) => dupError(rows, row, (r) => r.dni === v.dni, "Ya existe un trabajador con ese DNI."),
  },

  /* ---------------- GASTOS ---------------- */
  gastos: {
    key: "gastos", collection: "gastos", title: "Gastos", subtitle: "Egresos de cada estación por categoría.",
    newLabel: "Registrar gasto", itemLabel: (r) => `${r.categoria} · ${r.descripcion}`, sort: { key: "fecha", dir: "desc" },
    defaults: () => ({ fecha: Store.iso(), metodo: "Efectivo", usuario: Auth.getSession().user.name }),
    filters: [{ key: "fecha", label: "Fecha", type: "daterange" }, { key: "estacion", label: "Estación" }, { key: "categoria", label: "Categoría" }, { key: "metodo", label: "Pago" }],
    fields: [
      { key: "fecha", label: "Fecha", type: "date", required: true },
      { key: "estacion", label: "Estación", options: stationOpts, required: true },
      { key: "categoria", label: "Categoría", options: EXPENSE_CATS, required: true },
      { key: "descripcion", label: "Descripción", required: true },
      { key: "proveedor", label: "Proveedor" },
      { key: "metodo", label: "Método de pago", options: PAY_METHODS, required: true },
      { key: "monto", label: "Monto (S/)", type: "money", required: true, validate: (v) => (v <= 0 ? "Debe ser mayor a 0." : "") },
      { key: "comprobante", label: "Comprobante", placeholder: "F001-000123" },
      { key: "usuario", label: "Registrado por", readonly: true },
    ],
    summary: (rows) => `<span><b>${rows.length}</b> gastos</span><span><b>${Fmt.money(rows.reduce((a, r) => a + r.monto, 0))}</b> total</span>`,
  },
};

if (document.body.dataset.page && Modules[document.body.dataset.page]) Crud.init(Modules[document.body.dataset.page]);
