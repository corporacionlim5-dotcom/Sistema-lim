/* ==========================================================
   app.js — Núcleo compartido por todas las páginas
   Configuración, sesión, permisos, capa de datos (Api),
   menú lateral (Shell) y avisos (Toast).

   ARQUITECTURA FUTURA:
   Páginas -> Api (este archivo) -> Backend Node/Express -> BD
   Para conectar el backend: CONFIG.useMockApi = false y crear
   los endpoints /api que se indican en cada función de Api.
   ========================================================== */
"use strict";

/* ---------- 1. Configuración ---------- */
const CONFIG = {
  companyName: "Grupo Gasolineras",   // se puede cambiar en Configuración
  productName: "GasGestión",
  locale: "es-PE",
  currency: "PEN",
  apiBaseUrl: "/api",
  useMockApi: true,                    // true = datos guardados en el navegador
  showDemoHint: true,
  sessionKey: "gg_session",
  stationKey: "gg_station",
};

/* ---------- 2. Roles y permisos ----------
   Solo decide qué se MUESTRA. La seguridad real debe validarse en
   el servidor: cada endpoint /api comprobará el rol del usuario. */
const PERMISSIONS = {
  Administrador: ["dashboard", "estaciones", "ventas", "inventario", "personal", "gastos", "reportes", "configuracion"],
  Supervisor:    ["dashboard", "estaciones", "ventas", "inventario", "personal", "reportes"],
  Encargado:     ["dashboard", "ventas", "inventario", "personal"],
  Contador:      ["dashboard", "ventas", "gastos", "reportes"],
};

const MENU = [
  { key: "dashboard",     label: "Dashboard",     icon: "fa-gauge-high",    href: "dashboard.html" },
  { key: "estaciones",    label: "Estaciones",    icon: "fa-gas-pump",      href: "pages/estaciones.html" },
  { key: "ventas",        label: "Ventas",        icon: "fa-coins",         href: "pages/ventas.html" },
  { key: "inventario",    label: "Inventario",    icon: "fa-boxes-stacked", href: "pages/inventario.html" },
  { key: "personal",      label: "Personal",      icon: "fa-users",         href: "pages/personal.html" },
  { key: "gastos",        label: "Gastos",        icon: "fa-receipt",       href: "pages/gastos.html" },
  { key: "reportes",      label: "Reportes",      icon: "fa-chart-column",  href: "pages/reportes.html" },
  { key: "configuracion", label: "Configuración", icon: "fa-gear",          href: "pages/configuracion.html" },
];

/* ---------- 3. Utilidades ---------- */
const Fmt = {
  money: (n) => new Intl.NumberFormat(CONFIG.locale, { style: "currency", currency: CONFIG.currency }).format(n || 0),
  number: (n) => new Intl.NumberFormat(CONFIG.locale).format(n || 0),
  date: (iso) => (iso ? iso.split("-").reverse().join("/") : ""),
};

function esc(v) {
  return String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
const delay = (ms) => new Promise((r) => setTimeout(r, ms));

/* Descarga una tabla como CSV (Excel lo abre directamente) */
function downloadCSV(filename, rows) {
  const line = (r) => r.map((c) => `"${String(c ?? "").replace(/"/g, '""')}"`).join(";");
  const blob = new Blob(["\ufeff" + rows.map(line).join("\r\n")], { type: "text/csv;charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
}

const Toast = {
  show(msg, type = "success") {
    let c = document.getElementById("toasts");
    if (!c) { c = document.createElement("div"); c.id = "toasts"; c.className = "toast-container position-fixed bottom-0 end-0 p-3"; document.body.appendChild(c); }
    const t = document.createElement("div");
    t.className = `toast show align-items-center text-bg-${type} border-0`;
    t.innerHTML = `<div class="d-flex"><div class="toast-body">${esc(msg)}</div></div>`;
    c.appendChild(t);
    setTimeout(() => t.remove(), 3200);
  },
};

/* ---------- 4. Usuarios de demostración ----------
   ⚠ SOLO DEMO. En producción las contraseñas se guardan hasheadas
   (bcrypt/argon2) en la BD y se validan únicamente en el servidor. */
const MOCK_USERS = [
  { id: 1, username: "admin",      password: "admin123", name: "Carlos Mendoza",  role: "Administrador" },
  { id: 2, username: "supervisor", password: "super123", name: "Lucía Paredes",   role: "Supervisor" },
  { id: 3, username: "encargado",  password: "enc123",   name: "Jorge Quispe",    role: "Encargado" },
  { id: 4, username: "contador",   password: "cont123",  name: "Rosa Villanueva", role: "Contador" },
];

/* ---------- 5. Capa de datos (Api) ----------
   Las páginas SOLO usan Api.*. Hoy escribe en Store (navegador);
   mañana cada función llama al backend (ver comentarios BACKEND). */
const Api = {
  async http(path, options = {}) {
    const res = await fetch(CONFIG.apiBaseUrl + path, { credentials: "include", headers: { "Content-Type": "application/json" }, ...options });
    if (!res.ok) throw new Error(res.status === 401 ? "INVALID_CREDENTIALS" : "API_ERROR");
    return res.json();
  },

  /* BACKEND: POST /api/auth/login (hash + límite de intentos + cookie httpOnly) */
  async login(username, password) {
    if (!CONFIG.useMockApi) return this.http("/auth/login", { method: "POST", body: JSON.stringify({ username, password }) });
    await delay(400);
    const u = MOCK_USERS.find((x) => x.username === username.trim().toLowerCase() && x.password === password);
    if (!u) throw new Error("INVALID_CREDENTIALS");
    return { user: { id: u.id, name: u.name, username: u.username, role: u.role } };
  },
  /* BACKEND: POST /api/auth/logout */
  async logout() { if (!CONFIG.useMockApi) return this.http("/auth/logout", { method: "POST" }); },

  /* BACKEND: GET /api/{col}   POST /api/{col}   PUT /api/{col}/{id}   DELETE /api/{col}/{id}
     col = estaciones | ventas | inventario | personal | gastos */
  async list(col) {
    if (!CONFIG.useMockApi) return this.http("/" + col);
    return JSON.parse(JSON.stringify(Store.all(col)));
  },
  async create(col, data) {
    if (!CONFIG.useMockApi) return this.http("/" + col, { method: "POST", body: JSON.stringify(data) });
    return Store.insert(col, data);
  },
  async update(col, id, data) {
    if (!CONFIG.useMockApi) return this.http(`/${col}/${id}`, { method: "PUT", body: JSON.stringify(data) });
    return Store.update(col, id, data);
  },
  async remove(col, id) {
    if (!CONFIG.useMockApi) return this.http(`/${col}/${id}`, { method: "DELETE" });
    Store.remove(col, id);
  },

  async getStations() { return this.list("estaciones"); },

  /* BACKEND: GET /api/dashboard?station=all|E1  (consultas SQL con SUM/GROUP BY) */
  async getDashboard(stationId = "all") {
    if (!CONFIG.useMockApi) return this.http(`/dashboard?station=${encodeURIComponent(stationId)}`);
    const scope = (r) => stationId === "all" || r.estacion === stationId;
    const ventas = Store.all("ventas").filter(scope);
    const gastos = Store.all("gastos").filter(scope);
    const inv = Store.all("inventario").filter(scope);
    const sum = (arr, k) => arr.reduce((a, r) => a + r[k], 0);
    const today = Store.iso(), month = today.slice(0, 7);

    const ventasMes = sum(ventas.filter((v) => v.fecha.startsWith(month)), "total");
    const gastosMes = sum(gastos.filter((g) => g.fecha.startsWith(month)), "monto");

    // Últimos 14 días
    const dias = Array.from({ length: 14 }, (_, i) => { const d = new Date(); d.setDate(d.getDate() - (13 - i)); return d; });
    const labels = dias.map((d) => d.toLocaleDateString(CONFIG.locale, { day: "2-digit", month: "short" }));
    const values = dias.map((d) => sum(ventas.filter((v) => v.fecha === Store.iso(d)), "total"));

    // Gráfico 2: por estación (todas) o por método de pago (una)
    const delMes = ventas.filter((v) => v.fecha.startsWith(month));
    let distribucion;
    if (stationId === "all") {
      const est = Store.all("estaciones").filter((e) => delMes.some((v) => v.estacion === e.id));
      distribucion = { title: "Ventas del mes por estación", labels: est.map((e) => e.nombre), values: est.map((e) => sum(delMes.filter((v) => v.estacion === e.id), "total")) };
    } else {
      distribucion = { title: "Ventas del mes por método de pago", labels: PAY_METHODS, values: PAY_METHODS.map((m) => sum(delMes.filter((v) => v.metodo === m), "total")) };
    }

    const inventario = FUELS.map((fuel) => {
      const rows = inv.filter((i) => i.combustible === fuel);
      return { fuel, stock: rows.reduce((a, i) => a + Store.stock(i).actual, 0), capacity: sum(rows, "capacidad"), min: sum(rows, "minimo") };
    }).filter((t) => t.capacity > 0);

    const alertas = [];
    inv.forEach((i) => {
      const st = Store.stock(i).actual, meta = `${Store.stationName(i.estacion)} · ${Fmt.number(st)} L (mínimo ${Fmt.number(i.minimo)} L)`;
      if (st <= i.minimo) alertas.push({ level: "danger", text: `Stock bajo de ${i.combustible}`, meta });
      else if (st <= i.minimo * 1.25) alertas.push({ level: "warning", text: `${i.combustible} cerca del mínimo`, meta });
    });

    const operaciones = [
      ...ventas.map((v) => ({ k: v.fecha + v.hora, h: `${Fmt.date(v.fecha).slice(0, 5)} ${v.hora}`, estacion: Store.stationName(v.estacion), t: "Venta", d: `${v.combustible} · ${Fmt.number(v.litros)} L · ${v.metodo}`, m: v.total })),
      ...gastos.map((g) => ({ k: g.fecha + "00:00", h: Fmt.date(g.fecha).slice(0, 5), estacion: Store.stationName(g.estacion), t: "Gasto", d: `${g.categoria} · ${g.descripcion}`, m: g.monto })),
    ].sort((a, b) => b.k.localeCompare(a.k)).slice(0, 6);

    return {
      kpis: { ventasDia: sum(ventas.filter((v) => v.fecha === today), "total"), ventasMes, gastosMes, utilidad: ventasMes - gastosMes },
      ventasPorDia: { labels, values },
      distribucion,
      combustible: { labels: FUELS, values: FUELS.map((f) => sum(delMes.filter((v) => v.combustible === f), "litros")) },
      inventario, operaciones, alertas,
    };
  },
};

/* ---------- 6. Sesión ----------
   requireSession() solo mejora la experiencia. La protección real
   es el backend validando la sesión en cada petición. */
const Auth = {
  getSession() { try { return JSON.parse(sessionStorage.getItem(CONFIG.sessionKey)); } catch { return null; } },
  setSession(data) { sessionStorage.setItem(CONFIG.sessionKey, JSON.stringify({ ...data, loginAt: Date.now() })); },
  isLoggedIn() { return !!this.getSession(); },
  requireSession() {
    const s = this.getSession();
    if (!s) { location.replace(App.root + "login.html"); return null; }
    return s;
  },
  can(key) { const s = this.getSession(); return !!s && (PERMISSIONS[s.user.role] || []).includes(key); },
  async logout() {
    try { await Api.logout(); } catch { /* cerramos igual */ }
    sessionStorage.clear();
    location.replace(App.root + "login.html");
  },
};

/* ---------- 7. Estado de la aplicación ---------- */
const App = {
  root: document.body ? document.body.dataset.root || "" : "",
  companyName() { try { return Store.load().settings.companyName || CONFIG.companyName; } catch { return CONFIG.companyName; } },
  getStation() { return sessionStorage.getItem(CONFIG.stationKey) || "all"; },
  setStation(id) {
    sessionStorage.setItem(CONFIG.stationKey, id);
    document.dispatchEvent(new CustomEvent("station:change", { detail: { stationId: id } }));
  },
};

/* ---------- 8. Shell: menú lateral + barra superior ---------- */
const Shell = {
  logoHTML: (root) => `<span class="logo-box"><img src="${root}assets/logo.png" alt="" onerror="this.remove()"><i class="fa-solid fa-gas-pump" aria-hidden="true"></i></span>`,

  async render(activeKey) {
    const s = Auth.getSession();
    if (!s) return;
    const root = App.root;
    const initials = s.user.name.split(" ").slice(0, 2).map((w) => w[0]).join("").toUpperCase();

    const items = MENU.filter((m) => Auth.can(m.key)).map((m) =>
      `<li><a class="nav-x ${m.key === activeKey ? "active" : ""}" href="${root}${m.href}" ${m.key === activeKey ? 'aria-current="page"' : ""}><i class="fa-solid ${m.icon}"></i>${m.label}</a></li>`).join("");

    document.getElementById("sidebar").innerHTML = `
      <div class="sidebar-brand">
        ${this.logoHTML(root)}
        <div><div class="name">${esc(App.companyName())}</div><div class="sub">${esc(CONFIG.productName)}</div></div>
      </div>
      <ul class="sidebar-nav">${items}</ul>
      <div class="sidebar-foot">
        <div class="user-chip">
          <div class="avatar">${esc(initials)}</div>
          <div><div class="who">${esc(s.user.name)}</div><div class="role">${esc(s.user.role)}</div></div>
        </div>
        <button class="nav-x" id="logoutBtn" type="button"><i class="fa-solid fa-right-from-bracket"></i>Cerrar sesión</button>
      </div>`;

    const active = MENU.find((m) => m.key === activeKey);
    const showStation = activeKey === "dashboard";   // el selector aplica al dashboard
    document.getElementById("topbar").innerHTML = `
      <button class="menu-btn d-lg-none" id="menuBtn" type="button" aria-label="Abrir menú"><i class="fa-solid fa-bars"></i></button>
      <h1 class="page-title">${esc(active ? active.label : "")}</h1>
      <div class="spacer"></div>
      ${showStation ? `<label class="visually-hidden" for="stationSelect">Estación</label><select class="form-select form-select-sm station-select" id="stationSelect"></select>` : ""}
      <span class="today">${esc(new Date().toLocaleDateString(CONFIG.locale, { weekday: "long", day: "numeric", month: "long", year: "numeric" }))}</span>`;

    document.getElementById("logoutBtn").addEventListener("click", () => Auth.logout());
    document.getElementById("menuBtn").addEventListener("click", () => document.body.classList.toggle("sidebar-open"));
    document.getElementById("backdrop").addEventListener("click", () => document.body.classList.remove("sidebar-open"));

    if (showStation) {
      const stations = await Api.getStations();
      const sel = document.getElementById("stationSelect");
      sel.innerHTML = `<option value="all">Todas las estaciones</option>` + stations.map((st) =>
        `<option value="${esc(st.id)}" ${st.estado !== "Activa" ? "disabled" : ""}>${esc(st.nombre)}${st.estado !== "Activa" ? " (" + esc(st.estado.toLowerCase()) + ")" : ""}</option>`).join("");
      sel.value = App.getStation();
      if (sel.value !== App.getStation()) { sel.value = "all"; sessionStorage.setItem(CONFIG.stationKey, "all"); }
      sel.addEventListener("change", () => App.setStation(sel.value));
    }
  },
};
