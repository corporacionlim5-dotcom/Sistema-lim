/* ==========================================================
   reportes.js — Reportes por rango de fechas y estación
   Calcula ventas, gastos, utilidad y desgloses con los datos
   reales guardados. Excel = CSV; PDF = imprimir / guardar como PDF.
   ========================================================== */
"use strict";

(async function () {
  if (!Auth.requireSession()) return;
  if (!Auth.can("reportes")) { location.replace("../dashboard.html"); return; }
  await Shell.render("reportes");

  const $ = (id) => document.getElementById(id);
  const today = Store.iso();
  const monthStart = today.slice(0, 8) + "01";
  let data = {};

  $("report").innerHTML = `
    <div class="page-head d-flex flex-wrap justify-content-between align-items-end gap-2 mb-3">
      <div><h1>Reportes</h1><p>Resultados del periodo y la estación que elijas.</p></div>
      <div class="d-flex gap-2 no-print">
        <button class="btn btn-outline-secondary btn-sm" id="btnXls"><i class="fa-solid fa-file-excel me-1"></i>Exportar Excel</button>
        <button class="btn btn-outline-secondary btn-sm" id="btnPdf"><i class="fa-solid fa-file-pdf me-1"></i>Exportar PDF</button>
      </div>
    </div>
    <div class="panel mb-3 no-print"><div class="panel-body"><div class="row g-2 align-items-end">
      <div class="col-6 col-md-3"><label class="form-label" for="rFrom">Fecha inicial</label><input type="date" id="rFrom" class="form-control form-control-sm" value="${monthStart}"></div>
      <div class="col-6 col-md-3"><label class="form-label" for="rTo">Fecha final</label><input type="date" id="rTo" class="form-control form-control-sm" value="${today}"></div>
      <div class="col-12 col-md-4"><label class="form-label" for="rSt">Estación</label><select id="rSt" class="form-select form-select-sm"></select></div>
    </div></div></div>
    <div class="row g-3 mb-3" id="rKpis"></div>
    <div class="row g-3">
      <div class="col-xl-4"><section class="panel"><div class="panel-head"><h2>Ventas por combustible</h2></div><div class="panel-body table-responsive" id="tFuel"></div></section></div>
      <div class="col-xl-4"><section class="panel"><div class="panel-head"><h2>Ventas por trabajador</h2></div><div class="panel-body table-responsive" id="tWorker"></div></section></div>
      <div class="col-xl-4"><section class="panel"><div class="panel-head"><h2>Resultado por estación</h2></div><div class="panel-body table-responsive" id="tStation"></div></section></div>
    </div>`;

  const stations = await Api.list("estaciones");
  $("rSt").innerHTML = `<option value="">Todas las estaciones</option>` + stations.map((s) => `<option value="${esc(s.id)}">${esc(s.nombre)}</option>`).join("");
  data.ventas = await Api.list("ventas");
  data.gastos = await Api.list("gastos");
  data.personal = await Api.list("personal");

  const sum = (a, k) => a.reduce((x, r) => x + r[k], 0);
  const table = (heads, rows) => `<table class="table table-x"><thead><tr>${heads.map((h, i) => `<th class="${i ? "text-end" : ""}">${h}</th>`).join("")}</tr></thead><tbody>` +
    (rows.length ? rows.map((r) => `<tr>${r.map((c, i) => `<td class="${i ? "text-end num" : ""}">${esc(c)}</td>`).join("")}</tr>`).join("") : `<tr><td colspan="${heads.length}" class="empty">Sin datos en este periodo.</td></tr>`) + "</tbody></table>";

  let out = {};
  function calc() {
    const from = $("rFrom").value || "0000-00-00", to = $("rTo").value || "9999-99-99", st = $("rSt").value;
    const ok = (r) => r.fecha >= from && r.fecha <= to && (!st || r.estacion === st);
    const v = data.ventas.filter(ok), g = data.gastos.filter(ok);

    const ventas = sum(v, "total"), gastos = sum(g, "monto"), litros = sum(v, "litros");
    out.kpis = [["Ventas", Fmt.money(ventas)], ["Gastos", Fmt.money(gastos)], ["Utilidad", Fmt.money(ventas - gastos)], ["Litros vendidos", Fmt.number(Math.round(litros))]];
    out.fuel = FUELS.map((f) => { const x = v.filter((r) => r.combustible === f); return [f, Fmt.number(Math.round(sum(x, "litros"))) + " L", Fmt.money(sum(x, "total"))]; });
    out.worker = data.personal.map((p) => { const x = v.filter((r) => r.trabajador === p.id); return { n: p.nombre, l: sum(x, "litros"), t: sum(x, "total") }; })
      .filter((w) => w.t > 0).sort((a, b) => b.t - a.t).map((w) => [w.n, Fmt.number(Math.round(w.l)) + " L", Fmt.money(w.t)]);
    out.station = stations.filter((s) => !st || s.id === st).map((s) => { const a = sum(v.filter((r) => r.estacion === s.id), "total"), b = sum(g.filter((r) => r.estacion === s.id), "monto"); return [s.nombre, Fmt.money(a), Fmt.money(b), Fmt.money(a - b)]; })
      .filter((r) => r[1] !== Fmt.money(0) || r[2] !== Fmt.money(0));

    $("rKpis").innerHTML = out.kpis.map(([l, val], i) => `<div class="col-6 col-xl-3"><div class="panel kpi ${["", "k-cost", "k-profit", "k-month"][i]}"><div class="kpi-label">${l}</div><div class="kpi-value">${val}</div></div></div>`).join("");
    $("tFuel").innerHTML = table(["Combustible", "Litros", "Ventas"], out.fuel);
    $("tWorker").innerHTML = table(["Trabajador", "Litros", "Ventas"], out.worker);
    $("tStation").innerHTML = table(["Estación", "Ventas", "Gastos", "Utilidad"], out.station);
  }

  ["rFrom", "rTo", "rSt"].forEach((id) => $(id).addEventListener("change", calc));
  $("btnPdf").addEventListener("click", () => window.print());   // en el diálogo elige "Guardar como PDF"
  $("btnXls").addEventListener("click", () => {
    downloadCSV(`reporte-${$("rFrom").value}_${$("rTo").value}.csv`, [
      ["Reporte", `${Fmt.date($("rFrom").value)} al ${Fmt.date($("rTo").value)}`, $("rSt").selectedOptions[0].textContent], [],
      ...out.kpis, [], ["Combustible", "Litros", "Ventas"], ...out.fuel, [], ["Trabajador", "Litros", "Ventas"], ...out.worker, [], ["Estación", "Ventas", "Gastos", "Utilidad"], ...out.station,
    ]);
  });
  calc();
})();
