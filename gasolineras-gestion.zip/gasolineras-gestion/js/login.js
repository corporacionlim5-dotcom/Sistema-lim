/* ==========================================================
   login.js — Lógica de la pantalla de inicio de sesión
   Toda la validación real de credenciales ocurre en Api.login()
   (hoy simulada; mañana, el servidor).
   ========================================================== */
"use strict";

(function () {
  // Si ya hay sesión, ir directo al panel
  if (Auth.isLoggedIn()) { location.replace("dashboard.html"); return; }

  const $ = (id) => document.getElementById(id);
  const form = $("loginForm"), errorBox = $("loginError"), btn = $("loginBtn");
  const pwd = $("password");

  $("companyName").textContent = App.companyName();
  if (CONFIG.showDemoHint) $("demoHint").classList.remove("d-none");

  // Mostrar / ocultar contraseña
  $("togglePwd").addEventListener("click", () => {
    const show = pwd.type === "password";
    pwd.type = show ? "text" : "password";
    $("togglePwdIcon").className = show ? "fa-solid fa-eye-slash" : "fa-solid fa-eye";
    $("togglePwd").setAttribute("aria-label", show ? "Ocultar contraseña" : "Mostrar contraseña");
  });

  function showError(msg) {
    errorBox.textContent = msg;
    errorBox.classList.remove("d-none");
  }

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    errorBox.classList.add("d-none");

    const username = $("username").value.trim();
    const password = pwd.value;
    if (!username || !password) { showError("Escribe tu usuario y tu contraseña."); return; }

    btn.disabled = true;
    btn.textContent = "Ingresando…";
    try {
      const { user } = await Api.login(username, password);
      // El backend real dejará la sesión en una cookie httpOnly;
      // aquí guardamos solo datos de pantalla (nombre y rol), nunca la contraseña.
      Auth.setSession({ user });
      location.replace("dashboard.html");
    } catch (err) {
      showError(err.message === "INVALID_CREDENTIALS"
        ? "Usuario o contraseña incorrectos. Revisa los datos e inténtalo de nuevo."
        : "No se pudo conectar con el servidor. Inténtalo en unos minutos.");
      pwd.value = "";
      pwd.focus();
      btn.disabled = false;
      btn.textContent = "Iniciar sesión";
    }
  });
})();
