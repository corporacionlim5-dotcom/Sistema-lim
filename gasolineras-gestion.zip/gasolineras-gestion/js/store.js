/* ==========================================================
   store.js — Base de datos LOCAL (localStorage) para la demo
   Los datos se guardan en tu navegador y sobreviven al cerrar la
   página. Cuando exista el backend, este archivo desaparece:
   las páginas solo hablan con Api (app.js), nunca con Store.
   ========================================================== */
"use strict";

const FUELS = ["Regular 90", "Premium 95", "Diesel B5", "GLP"];
const PAY_METHODS = ["Efectivo", "Yape", "Plin", "Tarjeta", "Transferencia", "Otros"];
const EXPENSE_CATS = ["Personal", "Mantenimiento", "Servicios", "Combustible", "Alquiler", "Impuestos", "Transporte", "Otros"];
const CARGOS = ["Administrador", "Encargado", "Despachador", "Contador", "Supervisor", "Otro"];
const PREFIX = { estaciones: "E", ventas: "V", inventario: "I", personal: "P", gastos: "G" };

const Store = {
  KEY: "gg_db_v1",
  db: null,

  iso(d = new Date()) {
    const z = (n) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}`;
  },

  load() {
    if (this.db) return this.db;
    try { this.db = JSON.parse(localStorage.getItem(this.KEY)); } catch { this.db = null; }
    if (!this.db) { this.db = this.seed(); this.persist(); }
    return this.db;
  },
  persist() { localStorage.setItem(this.KEY, JSON.stringify(this.db)); },
  reset() { this.db = this.seed(); this.persist(); },
  replaceAll(obj) { this.db = obj; this.persist(); },

  all(col) { return this.load()[col]; },
  nextId(col) {
    const p = PREFIX[col];
    const max = this.all(col).reduce((m, r) => Math.max(m, parseInt(String(r.id).slice(p.length), 10) || 0), 0);
    return p + (max + 1);
  },
  insert(col, obj) { const row = { ...obj, id: this.nextId(col) }; this.all(col).push(row); this.persist(); return row; },
  update(col, id, patch) {
    const r = this.all(col).find((x) => x.id === id);
    if (!r) throw new Error("NOT_FOUND");
    Object.assign(r, patch, { id });
    this.persist();
    return r;
  },
  remove(col, id) { const db = this.load(); db[col] = db[col].filter((r) => r.id !== id); this.persist(); },

  /* Ayudantes de consulta */
  stationName(id) { const s = this.all("estaciones").find((x) => x.id === id); return s ? s.nombre : id || ""; },
  workerName(id) { const w = this.all("personal").find((x) => x.id === id); return w ? w.nombre : id || ""; },
  /* Stock = inicial + compras − litros vendidos (calculado desde Ventas) */
  stock(inv) {
    const vendido = this.all("ventas")
      .filter((v) => v.estacion === inv.estacion && v.combustible === inv.combustible)
      .reduce((a, v) => a + v.litros, 0);
    return { vendido: Math.round(vendido * 100) / 100, actual: Math.round((inv.stockInicial + inv.compras - vendido) * 100) / 100 };
  },

  /* ---------- Datos de demostración ---------- */
  seed() {
    let s = 42; // generador pseudoaleatorio fijo (mismos datos siempre)
    const rnd = () => { s |= 0; s = (s + 0x6d2b79f5) | 0; let t = Math.imul(s ^ (s >>> 15), 1 | s); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
    const pick = (a) => a[Math.floor(rnd() * a.length)];
    const z = (n) => String(n).padStart(2, "0");
    const r2 = (n) => Math.round(n * 100) / 100;

    const estaciones = [
      { id: "E1", codigo: "EST-001", nombre: "Estación 1", direccion: "Av. Principal 123", ciudad: "Lima", estado: "Activa", surtidores: 6, combustibles: FUELS.join(", "), responsable: "Jorge Quispe", horario: "24 horas", info: "" },
      { id: "E2", codigo: "EST-002", nombre: "Estación 2", direccion: "Av. Norte 456", ciudad: "Lima", estado: "Activa", surtidores: 4, combustibles: FUELS.join(", "), responsable: "Marco Ríos", horario: "06:00 - 22:00", info: "" },
      { id: "E3", codigo: "EST-003", nombre: "Estación 3", direccion: "", ciudad: "", estado: "Planificada", surtidores: 0, combustibles: "", responsable: "", horario: "", info: "Futura incorporación" },
      { id: "E4", codigo: "EST-004", nombre: "Estación 4", direccion: "", ciudad: "", estado: "Planificada", surtidores: 0, combustibles: "", responsable: "", horario: "", info: "Futura incorporación" },
    ];

    const w = (id, nombre, dni, cargo, estacion, tel, ingreso, turno) => ({ id, nombre, dni, cargo, estacion, telefono: tel, ingreso, estado: "Activo", turno });
    const personal = [
      w("P1", "Carlos Mendoza", "45123678", "Administrador", "E1", "987654321", "2019-03-01", "Mañana"),
      w("P2", "Jorge Quispe", "40234567", "Encargado", "E1", "987111222", "2020-06-15", "Mañana"),
      w("P3", "Marco Ríos", "41345678", "Encargado", "E2", "987333444", "2021-02-10", "Mañana"),
      w("P4", "Luis Huamán", "46456789", "Despachador", "E1", "987555666", "2022-01-05", "Mañana"),
      w("P5", "Ana Torres", "47567890", "Despachador", "E1", "987777888", "2022-08-20", "Tarde"),
      w("P6", "Pedro Salas", "48678901", "Despachador", "E2", "987999000", "2023-03-12", "Mañana"),
      w("P7", "Karla Núñez", "49789012", "Despachador", "E2", "986123456", "2023-09-01", "Tarde"),
      w("P8", "Rosa Villanueva", "42890123", "Contador", "E1", "986234567", "2020-01-20", "Mañana"),
      w("P9", "Lucía Paredes", "43901234", "Supervisor", "E1", "986345678", "2019-11-11", "Rotativo"),
    ];
    const dispatchers = { E1: ["P4", "P5"], E2: ["P6", "P7"] };

    const precio = { "Regular 90": 4.1, "Premium 95": 4.95, "Diesel B5": 4.2, GLP: 2.35 };
    const base = { "Regular 90": 700, "Premium 95": 250, "Diesel B5": 900, GLP: 350 };
    const escala = { E1: 1, E2: 0.75 };
    const metodos = ["Efectivo", "Efectivo", "Efectivo", "Yape", "Yape", "Plin", "Tarjeta", "Tarjeta", "Transferencia", "Otros"];

    const ventas = [];
    let vid = 1;
    for (let back = 29; back >= 0; back--) {
      const d = new Date(); d.setDate(d.getDate() - back);
      ["E1", "E2"].forEach((est) => FUELS.forEach((fuel) => {
        for (let k = 0; k < 2; k++) {
          const litros = r2((base[fuel] * escala[est] * (0.85 + rnd() * 0.3)) / 2);
          ventas.push({
            id: "V" + vid++, fecha: this.iso(d), hora: `${z(6 + Math.floor(rnd() * 16))}:${z(Math.floor(rnd() * 60))}`,
            estacion: est, surtidor: 1 + Math.floor(rnd() * estaciones.find((e) => e.id === est).surtidores),
            trabajador: pick(dispatchers[est]), combustible: fuel, litros, precio: precio[fuel],
            total: r2(litros * precio[fuel]), metodo: pick(metodos),
          });
        }
      }));
    }

    // Inventario: las compras se calculan para que el stock actual sea el objetivo
    const cfgInv = {
      E1: { "Regular 90": [8200, 15000, 3000], "Premium 95": [2100, 8000, 2000], "Diesel B5": [11500, 20000, 4000], GLP: [3200, 10000, 2500] },
      E2: { "Regular 90": [5400, 12000, 2500], "Premium 95": [1300, 6000, 1500], "Diesel B5": [9800, 18000, 3500], GLP: [6100, 8000, 2000] },
    };
    const pCompra = { "Regular 90": 3.6, "Premium 95": 4.3, "Diesel B5": 3.7, GLP: 1.95 };
    const inventario = [];
    let iid = 1;
    ["E1", "E2"].forEach((est) => FUELS.forEach((fuel) => {
      const [objetivo, capacidad, minimo] = cfgInv[est][fuel];
      const vendido = ventas.filter((v) => v.estacion === est && v.combustible === fuel).reduce((a, v) => a + v.litros, 0);
      const inicial = capacidad / 2;
      inventario.push({ id: "I" + iid++, estacion: est, combustible: fuel, stockInicial: inicial, compras: r2(objetivo - inicial + vendido), precioCompra: pCompra[fuel], precioVenta: precio[fuel], minimo, capacidad });
    }));

    // Gastos
    const desc = { Personal: "Pago de planilla", Mantenimiento: "Mantenimiento de surtidores", Servicios: "Recibo de luz y agua", Combustible: "Combustible para generador", Alquiler: "Alquiler de local", Impuestos: "Pago de impuestos SUNAT", Transporte: "Flete y transporte", Otros: "Gastos varios" };
    const provs = ["Distribuidora Andina SAC", "Servicios Técnicos Perú", "Luz del Sur", "Sedapal", "Transportes Rápidos", "Ferretería Central"];
    const gastos = [];
    let gid = 1;
    const monthStart = this.iso(new Date(new Date().getFullYear(), new Date().getMonth(), 1));
    ["E1", "E2"].forEach((est) => {
      gastos.push({ id: "G" + gid++, fecha: monthStart, estacion: est, categoria: "Alquiler", descripcion: desc.Alquiler, proveedor: "Inmobiliaria Lima SAC", metodo: "Transferencia", monto: 6500, comprobante: "F001-" + (100 + gid), usuario: "Carlos Mendoza" });
      gastos.push({ id: "G" + gid++, fecha: monthStart, estacion: est, categoria: "Personal", descripcion: desc.Personal, proveedor: "Planilla", metodo: "Transferencia", monto: 9500, comprobante: "PL-" + (200 + gid), usuario: "Carlos Mendoza" });
    });
    for (let i = 0; i < 22; i++) {
      const d = new Date(); d.setDate(d.getDate() - Math.floor(rnd() * 28));
      const cat = pick(EXPENSE_CATS.filter((c) => c !== "Alquiler" && c !== "Personal"));
      gastos.push({ id: "G" + gid++, fecha: this.iso(d), estacion: pick(["E1", "E2"]), categoria: cat, descripcion: desc[cat], proveedor: pick(provs), metodo: pick(PAY_METHODS), monto: r2(150 + rnd() * rnd() * 3800), comprobante: "F001-" + (300 + gid), usuario: "Carlos Mendoza" });
    }

    return { estaciones, personal, ventas, inventario, gastos, settings: { companyName: "Grupo Gasolineras", ruc: "" } };
  },
};
