/* ==========================================================
   crud.js — Motor reutilizable de tablas
   Una tabla con: buscar, filtrar, ordenar, paginar, ver,
   crear, editar, eliminar (con confirmación) y exportar.
   Cada módulo solo declara su configuración (ver modules.js).
   ========================================================== */
"use strict";

const Crud = (() => {
  const PAGE_SIZE = 10;

  /* ---------- Ayudantes de campos ---------- */
  const opts = (f) => {
    if (!f._c) {
      const o = typeof f.options === "function" ? f.options() : f.options || [];
      f._c = o.map((x) => (typeof x === "object" ? x : { value: x, label: x }));
    }
    return f._c;
  };
  const valueOf = (f, row) => (f.virtual ? f.virtual(row) : row[f.key]);
  const textOf = (f, row) => {
    const v = valueOf(f, row);
    if (f.options) { const o = opts(f).find((x) => String(x.value) === String(v)); return o ? o.label : v ?? ""; }
    if (f.type === "money") return v == null || v === "" ? "" : Fmt.money(v);
    if (f.type === "date") return Fmt.date(v);
    if (f.type === "number") return v == null || v === "" ? "" : Fmt.number(v);
    return v ?? "";
  };
  const cellHTML = (f, row) => {
    if (f.render) return f.render(row);
    const t = esc(textOf(f, row));
    return f.type === "money" || f.type === "number" ? `<span class="num">${t}</span>` : t;
  };

  /* ---------- Inicio ---------- */
  async function init(cfg) {
    if (!Auth.requireSession()) return;
    if (!Auth.can(cfg.key)) { location.replace(App.root + "dashboard.html"); return; }
    await Shell.render(cfg.key);

    const fields = cfg.fields;
    const cols = fields.filter((f) => f.table !== false);
    const formFields = fields.filter((f) => f.form !== false && !f.virtual);
    const st = { rows: [], sort: cfg.sort || { key: "id", dir: "asc" }, page: 1, q: "", filters: {} };
    const $ = (s) => document.querySelector(s);
    const deletable = (row) => (typeof cfg.canDelete === "function" ? cfg.canDelete(row) : cfg.canDelete !== false);

    /* Estructura de la página */
    $("#crud").innerHTML = `
      <div class="page-head d-flex flex-wrap justify-content-between align-items-end gap-2 mb-3">
        <div><h1>${esc(cfg.title)}</h1><p>${esc(cfg.subtitle || "")}</p></div>
        <div class="d-flex gap-2">
          <button class="btn btn-outline-secondary btn-sm" id="btnExport" type="button"><i class="fa-solid fa-file-csv me-1"></i>Exportar Excel</button>
          <button class="btn btn-brand btn-sm" id="btnNew" type="button"><i class="fa-solid fa-plus me-1"></i>${esc(cfg.newLabel || "Nuevo")}</button>
        </div>
      </div>
      <div class="panel"><div class="panel-body">
        <div class="row g-2 mb-3" id="filters"></div>
        <div id="summary"></div>
        <div class="table-responsive"><table class="table table-x table-hover"><thead id="thead"></thead><tbody id="tbody"></tbody></table></div>
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mt-2">
          <small class="text-secondary" id="pageInfo"></small><div class="btn-group btn-group-sm" id="pager"></div>
        </div>
      </div></div>`;

    /* Buscador y filtros */
    const filterHTML = (cfg.filters || []).map((f) => {
      if (f.type === "daterange") return `<div class="col-6 col-md-3 col-xl-2"><input type="date" class="form-control form-control-sm" data-fkey="${f.key}" data-range="from" title="${esc(f.label)} desde" aria-label="${esc(f.label)} desde"></div>
        <div class="col-6 col-md-3 col-xl-2"><input type="date" class="form-control form-control-sm" data-fkey="${f.key}" data-range="to" title="${esc(f.label)} hasta" aria-label="${esc(f.label)} hasta"></div>`;
      const field = fields.find((x) => x.key === f.key);
      return `<div class="col-6 col-md-3 col-xl-2"><select class="form-select form-select-sm" data-fkey="${f.key}" aria-label="${esc(f.label)}">
        <option value="">${esc(f.label)}: todos</option>${opts(field).map((o) => `<option value="${esc(o.value)}">${esc(o.label)}</option>`).join("")}</select></div>`;
    }).join("");
    $("#filters").innerHTML = `<div class="col-12 col-md-6 col-xl-3"><div class="input-group input-group-sm"><span class="input-group-text"><i class="fa-solid fa-magnifying-glass"></i></span><input type="search" class="form-control" id="q" placeholder="Buscar…" aria-label="Buscar"></div></div>` + filterHTML +
      (cfg.filters?.length ? `<div class="col-auto"><button class="btn btn-sm btn-link" id="clearF" type="button">Limpiar</button></div>` : "");

    /* ---------- Datos: filtrar + ordenar + paginar ---------- */
    function filtered() {
      const q = st.q.toLowerCase();
      let rows = st.rows.filter((r) => {
        for (const [k, v] of Object.entries(st.filters)) {
          if (!v) continue;
          if (k.endsWith("|from")) { if (r[k.split("|")[0]] < v) return false; }
          else if (k.endsWith("|to")) { if (r[k.split("|")[0]] > v) return false; }
          else if (String(r[k]) !== v) return false;
        }
        return !q || cols.some((f) => String(textOf(f, r)).toLowerCase().includes(q));
      });
      const f = fields.find((x) => x.key === st.sort.key), dir = st.sort.dir === "asc" ? 1 : -1;
      rows = rows.slice().sort((a, b) => {
        let x = f ? valueOf(f, a) : a[st.sort.key], y = f ? valueOf(f, b) : b[st.sort.key];
        if (f?.options) { x = textOf(f, a); y = textOf(f, b); }
        let c = typeof x === "number" && typeof y === "number" ? x - y : String(x ?? "").localeCompare(String(y ?? ""), "es", { numeric: true });
        if (!c && cfg.tieBreak) c = cfg.tieBreak(a, b);
        if (!c) c = (parseInt(String(a.id).slice(1), 10) || 0) - (parseInt(String(b.id).slice(1), 10) || 0);
        return c * dir;
      });
      return rows;
    }

    function render() {
      const rows = filtered();
      const pages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
      st.page = Math.min(st.page, pages);
      const start = (st.page - 1) * PAGE_SIZE, slice = rows.slice(start, start + PAGE_SIZE);

      $("#thead").innerHTML = "<tr>" + cols.map((f) => {
        const on = st.sort.key === f.key, icon = on ? (st.sort.dir === "asc" ? "fa-sort-up" : "fa-sort-down") : "fa-sort";
        const right = f.type === "money" || f.type === "number" ? "text-end" : "";
        return `<th class="sortable ${right}" data-sort="${f.key}" role="button">${esc(f.label)} <i class="fa-solid ${icon} ${on ? "" : "opacity-25"}"></i></th>`;
      }).join("") + `<th class="text-end">Acciones</th></tr>`;

      $("#tbody").innerHTML = slice.length ? slice.map((r) => {
        const acts = (cfg.actions || []).filter((a) => !a.show || a.show(r)).map((a, i) => `<button class="btn btn-sm btn-light" data-act="x${(cfg.actions || []).indexOf(a)}" data-id="${r.id}" title="${esc(a.title)}"><i class="fa-solid ${a.icon}"></i></button>`).join("");
        return `<tr class="${cfg.rowClass ? cfg.rowClass(r) : ""}">` + cols.map((f) => `<td class="${f.type === "money" || f.type === "number" ? "text-end" : ""}">${cellHTML(f, r)}</td>`).join("") +
          `<td class="text-end text-nowrap">
            <button class="btn btn-sm btn-light" data-act="view" data-id="${r.id}" title="Ver detalle"><i class="fa-solid fa-eye"></i></button>
            <button class="btn btn-sm btn-light" data-act="edit" data-id="${r.id}" title="Editar"><i class="fa-solid fa-pen"></i></button>
            ${acts}${deletable(r) ? `<button class="btn btn-sm btn-light text-danger" data-act="del" data-id="${r.id}" title="Eliminar"><i class="fa-solid fa-trash"></i></button>` : ""}
          </td></tr>`;
      }).join("") : `<tr><td colspan="${cols.length + 1}" class="empty">No hay registros que coincidan. Ajusta los filtros o crea uno nuevo.</td></tr>`;

      $("#pageInfo").textContent = rows.length ? `Mostrando ${start + 1}–${start + slice.length} de ${rows.length}` : "0 registros";
      const btn = (p, label, dis, act) => `<button class="btn btn-outline-secondary ${act ? "active" : ""}" data-page="${p}" ${dis ? "disabled" : ""}>${label}</button>`;
      const nums = [];
      for (let p = Math.max(1, st.page - 2); p <= Math.min(pages, st.page + 2); p++) nums.push(btn(p, p, false, p === st.page));
      $("#pager").innerHTML = btn(st.page - 1, "‹", st.page === 1) + nums.join("") + btn(st.page + 1, "›", st.page === pages);
      $("#summary").innerHTML = cfg.summary ? `<div class="summary">${cfg.summary(rows)}</div>` : "";
    }

    async function refresh() {
      fields.forEach((f) => delete f._c);           // recalcula listas (estaciones, etc.)
      st.rows = await Api.list(cfg.collection);
      render();
    }

    /* ---------- Ventanas (modal) ---------- */
    document.body.insertAdjacentHTML("beforeend", `
      <div class="modal fade" id="mForm" tabindex="-1"><div class="modal-dialog modal-lg modal-dialog-scrollable"><div class="modal-content">
        <div class="modal-header"><h5 class="modal-title" id="mTitle"></h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button></div>
        <div class="modal-body" id="mBody"></div>
        <div class="modal-footer" id="mFoot"></div></div></div></div>
      <div class="modal fade" id="mConfirm" tabindex="-1"><div class="modal-dialog modal-dialog-centered"><div class="modal-content">
        <div class="modal-body p-4"><h5>¿Eliminar este registro?</h5><p class="mb-0 text-secondary" id="cMsg"></p></div>
        <div class="modal-footer"><button class="btn btn-light" data-bs-dismiss="modal">Cancelar</button><button class="btn btn-danger" id="cOk">Sí, eliminar</button></div></div></div></div>`);
    const mForm = new bootstrap.Modal("#mForm"), mConfirm = new bootstrap.Modal("#mConfirm");

    const readForm = () => {
      const vals = {};
      formFields.forEach((f) => {
        const el = document.getElementById("f_" + f.key);
        const num = f.type === "number" || f.type === "money";
        vals[f.key] = num ? (el.value === "" ? null : Number(el.value)) : el.value.trim();
      });
      return vals;
    };
    const recompute = (changed) => {
      const vals = readForm();
      formFields.filter((f) => f.computed).forEach((f) => { document.getElementById("f_" + f.key).value = f.computed(vals); });
      if (cfg.onChange) cfg.onChange(readForm(), (k, v) => { document.getElementById("f_" + k).value = v; }, changed);
      formFields.filter((f) => f.computed).forEach((f) => { document.getElementById("f_" + f.key).value = f.computed(readForm()); });
    };

    function fieldHTML(f, val) {
      const id = "f_" + f.key, req = f.required ? "required" : "";
      let input;
      if (f.options) {
        input = `<select class="form-select" id="${id}" ${req}><option value="">Seleccionar…</option>${opts(f).map((o) => `<option value="${esc(o.value)}" ${String(o.value) === String(val) ? "selected" : ""}>${esc(o.label)}</option>`).join("")}</select>`;
      } else if (f.type === "textarea") {
        input = `<textarea class="form-control" id="${id}" rows="2">${esc(val)}</textarea>`;
      } else {
        const num = f.type === "number" || f.type === "money";
        const step = f.type === "money" ? "0.01" : f.step || "1";
        input = `<input class="form-control" id="${id}" type="${num ? "number" : f.type || "text"}" value="${esc(val)}" ${req}
          ${num ? `step="${step}" min="${f.min ?? 0}"` : ""} ${f.maxlength ? `maxlength="${f.maxlength}"` : ""} ${f.readonly || f.computed ? "readonly" : ""} ${f.placeholder ? `placeholder="${esc(f.placeholder)}"` : ""}>`;
      }
      return `<div class="${f.type === "textarea" ? "col-12" : "col-md-6"}"><label class="form-label" for="${id}">${esc(f.label)}${f.required ? " *" : ""}</label>${input}
        <div class="invalid-feedback" id="e_${f.key}"></div>${f.hint ? `<div class="form-text">${esc(f.hint)}</div>` : ""}</div>`;
    }

    function openForm(row) {
      const editing = !!row;
      const base = editing ? row : Object.fromEntries(formFields.map((f) => [f.key, ""]));
      const init = editing ? base : { ...base, ...(cfg.defaults ? cfg.defaults() : {}) };
      $("#mTitle").textContent = editing ? `Editar: ${cfg.itemLabel(row)}` : cfg.newLabel || "Nuevo registro";
      $("#mBody").innerHTML = `<div class="alert alert-danger py-2 d-none" id="fErr"></div><form id="cform" class="row g-3" novalidate>${formFields.map((f) => fieldHTML(f, init[f.key])).join("")}</form>`;
      $("#mFoot").innerHTML = `<button class="btn btn-light" data-bs-dismiss="modal">Cancelar</button><button class="btn btn-brand" id="btnSave"><i class="fa-solid fa-floppy-disk me-1"></i>Guardar</button>`;
      $("#cform").addEventListener("input", (e) => recompute(e.target.id.slice(2)));
      $("#cform").addEventListener("change", (e) => recompute(e.target.id.slice(2)));
      $("#cform").addEventListener("submit", (e) => { e.preventDefault(); save(row); });
      $("#btnSave").addEventListener("click", () => save(row));
      if (!editing) recompute("");
      mForm.show();
    }

    async function save(row) {
      const vals = readForm();
      let ok = true;
      formFields.forEach((f) => {
        const el = document.getElementById("f_" + f.key), v = vals[f.key];
        let msg = "";
        if (f.required && (v === "" || v === null)) msg = "Este campo es obligatorio.";
        else if (f.pattern && v && !f.pattern.test(v)) msg = f.patternMsg || "Formato no válido.";
        else if (f.validate && v !== "" && v !== null) msg = f.validate(v, vals) || "";
        el.classList.toggle("is-invalid", !!msg);
        document.getElementById("e_" + f.key).textContent = msg;
        if (msg) ok = false;
      });
      if (!ok) return;
      try {
        if (cfg.beforeSave) cfg.beforeSave(vals, row, st.rows);
        $("#btnSave").disabled = true;
        row ? await Api.update(cfg.collection, row.id, vals) : await Api.create(cfg.collection, vals);
        mForm.hide();
        Toast.show(row ? "Cambios guardados." : "Registro creado.");
        await refresh();
      } catch (err) {
        $("#fErr").textContent = err.message; $("#fErr").classList.remove("d-none");
        $("#btnSave").disabled = false;
      }
    }

    function openView(row) {
      $("#mTitle").textContent = cfg.itemLabel(row);
      $("#mBody").innerHTML = `<dl class="row mb-0">${fields.map((f) => `<dt class="col-sm-4 text-secondary fw-normal">${esc(f.label)}</dt><dd class="col-sm-8">${f.render && !f.plain ? f.render(row) : esc(textOf(f, row)) || "—"}</dd>`).join("")}</dl>`;
      $("#mFoot").innerHTML = `<button class="btn btn-light" data-bs-dismiss="modal">Cerrar</button><button class="btn btn-brand" id="vEdit"><i class="fa-solid fa-pen me-1"></i>Editar</button>`;
      $("#vEdit").addEventListener("click", () => { mForm.hide(); setTimeout(() => openForm(row), 250); });
      mForm.show();
    }

    function askDelete(row) {
      $("#cMsg").textContent = `${cfg.itemLabel(row)}. Esta acción no se puede deshacer.`;
      const ok = $("#cOk").cloneNode(true);           // evita acumular eventos
      $("#cOk").replaceWith(ok);
      ok.addEventListener("click", async () => {
        try { await Api.remove(cfg.collection, row.id); mConfirm.hide(); Toast.show("Registro eliminado."); await refresh(); }
        catch (e) { Toast.show(e.message, "danger"); }
      });
      mConfirm.show();
    }

    /* ---------- Eventos ---------- */
    $("#btnNew").addEventListener("click", () => openForm(null));
    $("#btnExport").addEventListener("click", () => {
      const rows = filtered();
      downloadCSV(`${cfg.key}-${Store.iso()}.csv`, [cols.map((f) => f.label), ...rows.map((r) => cols.map((f) => textOf(f, r)))]);
    });
    $("#q").addEventListener("input", (e) => { st.q = e.target.value; st.page = 1; render(); });
    $("#filters").addEventListener("change", (e) => {
      const k = e.target.dataset.fkey; if (!k) return;
      st.filters[e.target.dataset.range ? `${k}|${e.target.dataset.range}` : k] = e.target.value; st.page = 1; render();
    });
    const clear = document.getElementById("clearF");
    if (clear) clear.addEventListener("click", () => { st.filters = {}; st.q = ""; $("#q").value = ""; document.querySelectorAll("#filters [data-fkey]").forEach((el) => (el.value = "")); st.page = 1; render(); });
    $("#thead").addEventListener("click", (e) => {
      const th = e.target.closest("[data-sort]"); if (!th) return;
      const k = th.dataset.sort;
      st.sort = { key: k, dir: st.sort.key === k && st.sort.dir === "asc" ? "desc" : "asc" }; render();
    });
    $("#pager").addEventListener("click", (e) => { const b = e.target.closest("[data-page]"); if (b && !b.disabled) { st.page = Number(b.dataset.page); render(); } });
    $("#tbody").addEventListener("click", async (e) => {
      const b = e.target.closest("[data-act]"); if (!b) return;
      const row = st.rows.find((r) => r.id === b.dataset.id), act = b.dataset.act;
      if (act === "view") openView(row);
      else if (act === "edit") openForm(row);
      else if (act === "del") askDelete(row);
      else if (act.startsWith("x")) { await cfg.actions[Number(act.slice(1))].handler(row); await refresh(); }
    });

    await refresh();
  }

  return { init };
})();
