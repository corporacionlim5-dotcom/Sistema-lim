/* ==========================================================
   configuracion.js — Datos de la empresa y copias de seguridad
   ========================================================== */
"use strict";

(async function () {
  if (!Auth.requireSession()) return;
  if (!Auth.can("configuracion")) { location.replace("../dashboard.html"); return; }
  await Shell.render("configuracion");

  const $ = (id) => document.getElementById(id);
  const cfg = Store.load().settings;

  $("settings").innerHTML = `
    <div class="page-head mb-3"><h1>Configuración</h1><p>Datos de la empresa y respaldo de la información.</p></div>
    <div class="row g-3">
      <div class="col-lg-6"><section class="panel"><div class="panel-head"><h2>Datos de la empresa</h2></div><div class="panel-body">
        <div class="mb-3"><label class="form-label" for="sName">Nombre de la empresa</label><input class="form-control" id="sName" value="${esc(cfg.companyName)}"></div>
        <div class="mb-3"><label class="form-label" for="sRuc">RUC</label><input class="form-control" id="sRuc" maxlength="11" value="${esc(cfg.ruc)}"></div>
        <button class="btn btn-brand" id="sSave"><i class="fa-solid fa-floppy-disk me-1"></i>Guardar cambios</button>
      </div></section></div>
      <div class="col-lg-6"><section class="panel"><div class="panel-head"><h2>Copia de seguridad</h2></div><div class="panel-body">
        <p class="text-secondary">Los datos se guardan en este navegador. Descarga una copia con regularidad; al conectar la base de datos ya no será necesario.</p>
        <div class="d-flex flex-wrap gap-2">
          <button class="btn btn-outline-secondary" id="bExport"><i class="fa-solid fa-download me-1"></i>Descargar copia (JSON)</button>
          <button class="btn btn-outline-secondary" id="bImport"><i class="fa-solid fa-upload me-1"></i>Restaurar copia</button>
          <input type="file" id="bFile" accept="application/json" class="d-none">
        </div>
        <hr>
        <p class="text-secondary mb-2">Borra todo lo registrado y vuelve a los datos de ejemplo.</p>
        <button class="btn btn-outline-danger" id="bReset"><i class="fa-solid fa-rotate-left me-1"></i>Restaurar datos de demostración</button>
      </div></section></div>
    </div>`;

  $("sSave").addEventListener("click", () => {
    const name = $("sName").value.trim();
    if (!name) { Toast.show("Escribe el nombre de la empresa.", "danger"); return; }
    Store.load().settings = { companyName: name, ruc: $("sRuc").value.trim() };
    Store.persist();
    Toast.show("Datos guardados.");
    setTimeout(() => location.reload(), 600);
  });
  $("bExport").addEventListener("click", () => {
    const blob = new Blob([JSON.stringify(Store.load(), null, 2)], { type: "application/json" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = `respaldo-gasolineras-${Store.iso()}.json`; a.click();
  });
  $("bImport").addEventListener("click", () => $("bFile").click());
  $("bFile").addEventListener("change", async (e) => {
    try {
      const obj = JSON.parse(await e.target.files[0].text());
      if (!obj.estaciones || !obj.ventas || !obj.gastos) throw new Error();
      if (!confirm("Esto reemplazará todos los datos actuales. ¿Continuar?")) return;
      Store.replaceAll(obj); Toast.show("Copia restaurada."); setTimeout(() => location.reload(), 600);
    } catch { Toast.show("El archivo no es una copia válida.", "danger"); }
  });
  $("bReset").addEventListener("click", () => {
    if (!confirm("Se borrarán TODOS los datos registrados. ¿Continuar?")) return;
    Store.reset(); Toast.show("Datos de demostración restaurados."); setTimeout(() => location.reload(), 600);
  });
})();
